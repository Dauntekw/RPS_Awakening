#pragma once

void dot_list_fill(int row, int column);
void logo_init(void);
void logo_update(void);
void logo_exit(void);