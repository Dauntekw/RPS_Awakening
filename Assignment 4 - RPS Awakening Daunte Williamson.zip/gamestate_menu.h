#pragma once
#include "gamestate_rps.h"
CP_Image bg;
CP_Image scroll;
void menu_init(void);
void menu_update(void);
void menu_exit(void);
