#pragma once
void tutorial_init(void);
void tutorial_update(void);
void tutorial_exit(void);